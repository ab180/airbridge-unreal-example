//
//  ABBackgroundEvent.h
//  AirBridge
//
//  Created by WOF on 06/03/2019.
//  Copyright © 2019 ab180. All rights reserved.
//

#import <AirBridge/ABEvent.h>

NS_ASSUME_NONNULL_BEGIN

@interface ABBackgroundEvent : ABEvent

- (instancetype)init;

@end

NS_ASSUME_NONNULL_END
